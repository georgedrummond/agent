# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
GitlabCi::Application.config.secret_token = '78140d64a8cee2937e883d9ff91a5a554c01e30c0e0042b470cd574d19462da8a607abdc23fa501c4580c74655742990a1da88ef03485c3cf9ac370f12e9397a'
