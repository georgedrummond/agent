## ROADMAP: 

1. Email notification
2. Authorization. 2 types of users (admin and user)
3. API
