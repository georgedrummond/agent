require 'spec_helper'

describe "Builds" do
  describe "GET /:project/builds" do

  end
end
